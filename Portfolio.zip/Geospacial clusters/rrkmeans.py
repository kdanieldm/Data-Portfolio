#**********************
# This code clusters points: lat and long, for a city.
#----------------------------------------------------------------
# Author:K. De Alba
# Creation Date: 2020-06-01
#______________________

import pandas as pd, numpy as np, matplotlib.pyplot as plt
from scipy.cluster.vq import kmeans2, whiten
from sklearn.cluster import KMeans
import seaborn as sns
sns.set()

# select data frame
df = pd.read_csv('input file')

# drop the useless columns.
dfx = df.drop(['container_size'], axis = 1)
coords = dfx.to_numpy()


# definimos los weights y graficamos el elbow.
wcss = []
for i in range(1,11):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 42)
    kmeans.fit(coords)
    wcss.append(kmeans.inertia_)

plt.figure(figsize = (10,8))
plt.plot(range(1, 11), wcss, marker = 'o', linestyle = '--')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
plt.title('K-means Clustering')
plt.show()

# We run K-means with a fixed number of clusters. In our case 4.
kmeans = KMeans(n_clusters = 6, init = 'k-means++', random_state = 42)

# We divide our data into the four clusters.
kmeans.fit(coords)
# We create a new data frame with the original features and add a new column with the assigned clusters for each point.
df_segm_kmeans = dfx.copy()
df_segm_kmeans['Segment K-means'] = kmeans.labels_
df_segm_kmeans
# Calculate mean values for the clusters
df_segm_analysis = df_segm_kmeans.groupby(['Segment K-means']).mean()
df_segm_analysis

df_segm_kmeans['Labels'] = df_segm_kmeans['Segment K-means'].map({0:'one',
                                                                  1:'two',
                                                                  2:'three',
                                                                  3:'four',
                                                                  4:'five',
                                                                  5:'six'})
                                                                  # We plot the results from the K-means algorithm.
# Each point in our data set is plotted with the color of the clusters it has been assigned to.
x_axis = df_segm_kmeans['rloc_long']
y_axis = df_segm_kmeans['rloc_lat']
plt.figure(figsize = (10, 8))
sns.scatterplot(x_axis, y_axis, hue=df_segm_kmeans['Labels'], palette=["#9b59b6", "#3498db", "#95a5a6", "#e74c3c", "#34495e", "#2ecc71"])
plt.title('Segmentation K-means')
plt.show()

df_segm_kmeans.to_csv('df_2_kepler.csv', index=False)




