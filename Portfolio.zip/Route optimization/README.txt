This program optimize the routes considering time, distance variables for a certain city graph.

For security reasons, I've delete the config file..

1 - The main fail extract database info and cleanse the data thus the algorithm (VRP) may run without failures.

2 - I use the connection to the db using the config file, but you can check the queries I used to grab the info from the databasee in queries.py

3 - The algorithm file, VRP 1.3.py
