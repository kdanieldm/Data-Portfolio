# Este code funciona para calcular la matriz distancia tiempo.
# ----------------------------------------------------------------
#******************************************
#******************************************
# Author: Kevin De Alba
# Creation Date: 2021-01-22
#__________________________________________
# Input: - guadalajara_network.graphml
# Output: - constrainst.csv, time-distance-matrix.csv
#__________________________________________
from networkx.generators.classic import path_graph
import config as cfg
import queries as qrs
import re
from datetime import datetime
from sqlalchemy import create_engine
from os import write
import osmnx as ox
import networkx as nx
import pandas as pd
from itertools import permutations
import psycopg2
import io
from sqlalchemy import create_engine
from sqlalchemy import delete
import re
from datetime import datetime
import webbrowser
import vrp_1_3 # es el archivo del algortimo.
import os
import smtplib
import ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from queries import *

# today = datetime.today()
# date = today.strftime('X%d/X%m/%Y').replace('X0','X').replace('X','')

date = '10/12/2020'

class raypal_db:
    def __init__(self):

        global cur
        global conn
        conn = psycopg2.connect(database = cfg.key["db"], 
                                user = cfg.key["user"], 
                                password = cfg.key["password"],
                                host = cfg.key["host"], 
                                port = cfg.key["port"])
        cur = conn.cursor()

    def execute(self, query):
        self.query = query
        return cur.execute(query)

    def get_query(self, query):

        self.query = query
        cur.execute(query.format_map({'d_f' : date}))
        records = cur.fetchall()
        col_names = []
        for elt in cur.description:
            col_names.append(elt[0])

        data_frame = pd.DataFrame(records, columns=col_names)
        return data_frame


    def update(self, dataframe, table_name):

        self.table_name = table_name
        self.dataframe = dataframe
        
        engine = create_engine(cfg.key["engine"])
        dataframe.to_sql(table_name, engine, if_exists='replace')

    
    def close(self):
        conn.close()
        print("database close successfully")


class data:
    
    def query(self, query_name):

        self.query_name = query_name
        psql = raypal_db()
        q1 = psql.get_query(qrs.sql[query_name])
        raypal_db.close
        return q1

class email:
    def send(self, subject, body, file = 'NA'):
        
        self.subject = subject
        self.body = body

        sender_email = cfg.email["email"]
        password = cfg.email["pwd"]

        # Create a multipart message and set headers
        recipients = list(cfg.client.values())

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = ", ".join(recipients)
        message["Subject"] = subject


        # Add body to email
        message.attach(MIMEText(body, "plain"))

        self.file = file  # In same directory as script

        # Open  file in binary mode
        with open(file, "rb") as attachment:
            # Add file as application/octet-stream
            # Email client can usually download this automatically as attachment
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())

        # Encode file in ASCII characters to send by email
        encoders.encode_base64(part)

        # Add header as key/value pair to attachment part
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {file}",
        )

        # Add attachment to message and convert message to string
        message.attach(part)
        text = message.as_string()

        # Log in to server using secure context and send email
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, recipients, text)

class calculus:

    def __init__(self, routepath, file):

        dataframe = data()
        df = dataframe.query('rr_request')
        print(df)
        

        #Configure osmnx
        global G
        ox.config(log_console=True, use_cache=False)
        #Load the graph file of GDL
        G = ox.load_graphml('{}{}'.format(routepath, file))

    # def nodes_():

        #Select the route_id and the localization
        nodes = []
        for index, row in df.iterrows():
            a = ox.get_nearest_node(G, (row['loc_lat'], row['loc_long']))
            nodes.append(a)

        bodega = ox.get_nearest_node(G, (20.619651, -103.342885))
        depot = pd.DataFrame({"rr_id": [1],
                            "loc_lat": [20.619651],
                            "loc_long": [-103.342885],
                            "nearest_node": [bodega]
                            })
        nodes = pd.DataFrame(nodes, columns=['nearest_node'])
        df = pd.concat([df.reset_index(drop=True), nodes], axis=1)
        df = df.append(depot, ignore_index=True)
        # df.to_csv('rr_id_test.csv')
        nearest_node = list(df.iloc[:, 3])
        # df.to_csv('test2.csv')

        # Get all permutations of length 2
        permutation = []
        perm = permutations(nearest_node, 2)
        # Print the obtained permutations
        for i in list(perm):
            permutation.append(i)

        nodes_perm = pd.DataFrame(permutation, columns=[
                                'orig_node', 'target_node'])
        # nodes_perm.to_csv('test3.csv')

    # SHORTEST PATH LENGTH
        length = []
        time = []
        for index, row in nodes_perm.iterrows():
            r = nx.shortest_path_length(
                G=G, source=row['orig_node'], target=row['target_node'], 
                weight='length')
            d = r/1000 # en km
            t = (0.0004*d**3  - 0.0417*d**2 + 2.2618*d + 2.4319)*60 # t en secs
            length.append(r)
            time.append(t)

        #Add a column for the nodes permutated and add the distance in meters
        length = pd.DataFrame(length, columns=['length_m'])
        time_ = pd.DataFrame(time, columns=['time_s'])
        df_distance = pd.concat([nodes_perm.reset_index(drop=True),
                                length, time_, df], axis=1)
        # df_distance = df_distance.dropna()
        print(df_distance.head())
        # df_distance.to_csv('distance.csv')

    # Escribe en la database los dataframes de la matriz
        write = raypal_db()
        write.update(df_distance, 'distances_matrix1')

        write.update(df, 'table_node_rrid')

    # TIME DISTANCE MATRIX (FINAL QUERY)
        
        try:
            outputquery = dataframe.query('time-distance')
            # outputquery.to_csv('time-distance-matrix.csv')
    
        except psycopg2.Error as e:
        # get error code
            msg = email()
            msg.send('Sin recolecciones', 'NA')
            
    # TIME WINDOWS
        try:
            df_cons = dataframe.query('constraint')
            df_cons = df_cons.drop(['horario_min', 'horario_max'], axis=1)

            # outputquery.to_csv('time-distance-matrix.csv')
            print(df_cons)

                # Corregir el formato de hora.
            hrs = []
            hrs1 = []
                
            for i in range(0, len(df_cons)):
                time = re.split(' - | -|- ', df_cons['hours'][i])
                a = datetime.strptime(time[0], '%I %p').hour
                b = datetime.strptime(time[1], '%I %p').hour
                hrs.append(a)
                hrs1.append(b)
                
            df_min = pd.DataFrame(hrs)
            df_max = pd.DataFrame(hrs1)

            df_min.apply(lambda x: pd.Series(x[0])).stack().reset_index(level=1, drop=True)
            df_max.apply(lambda x: pd.Series(x[0])).stack().reset_index(level=1, drop=True)

            merged = pd.concat([df_cons, df_min, df_max], ignore_index=True, axis = 1)
            
            merged.columns = ['rr_id', 'sdate','na', 'horario_min', 'horario_max']
            merged['horario_min'] = 3600 * merged['horario_min']
            merged['horario_max'] = 3600 * merged['horario_max']
            merged.set_index('rr_id', inplace=True)
            merged = merged.drop(columns = ['na'])
            
            #select max value
            merged_1 = merged.groupby('rr_id', as_index=True).max()
            merged_1 = merged_1.drop(columns = ['horario_min', 'sdate'])

      
            #select min value
            merged_2 = merged.groupby('rr_id', as_index=True).min()
            merged_2 = merged_2.drop(columns = ['horario_max'])


            d3 = pd.concat([merged_2, merged_1], axis = 1)
            # d3.to_csv('constraintsa.csv') #data frame corregido, constraints unicos
            print("Operation done, successfully change hour format", d3)
                
        except:
            print("Error")

class vrp_model:
    def __init__(self):
        vrp_1_3.main()
        return

class mapping:
    def __init__(self):
        global url_short

        dataframe = data()
        df_map = dataframe.query('google-map')
        df_map.set_index("rr_id", inplace=True)
        df_map.reset_index()
        
        data_frame = pd.read_csv('entregable_1.csv')
        
        # Reordena el rr_id segun el algortimo.
        rr_id_order = data_frame['rr_id'].to_list()
        df2 = df_map.reindex(rr_id_order)
        print(df2)

        raypal = "20.61967,-103.34281"
        route = """https://www.google.com/maps/dir/?api=1&origin={dir_0}&destination={dir_1}&waypoints=""".format(dir_0 = raypal,
                                                dir_1 = raypal)
        waypoints = [i for i in df2['address']]
        res = '%7C'.join(waypoints)
        link = route + res
        link = link.replace(" ", "+")
        link = link.replace(".,", ".")
        # webbrowser.open(link)

        import url_shortener
        url_short = url_shortener.make_shorten(link)

        return

    

def main():
    path = os.getcwd()
    router = calculus(path,
                    '/guadalajara_network.graphml')
    algorithm = vrp_model()
    g_map = mapping()

    # Send response email 
    csv = data()
    file_csv = csv.query('csv_2_driver')
    file_csv.to_csv('csv_2_driver.csv')

    msg = email()
    msg.send('Correo de prueba', 'Plan del dia: {date}, {lk}'.
                format_map({'date' : date,
                            'lk':url_short}), 'csv_2_driver.csv')
    print('Email sended successfully')
 

if __name__ == '__main__':
    main()
