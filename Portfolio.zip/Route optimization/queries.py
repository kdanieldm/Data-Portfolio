sql = {'rr_request' : """select distinct a.rr_id, ad.loc_lat, ad.loc_long
	from
	
        (select * from user_app
        ) c
	
	left join 
	
        (select * from address
        ) ad on c.id_user=ad.id_user
	
	left join 
	
        (select * from recollection_request where rr_status not in (5,4)
        
        ) a on c.id_user=a.id_user
	
	left join 
	
        (select * from scheduled_datetimes
        where sdate in ('{d_f}')
        ) b on a.rr_id=b.rr_id
	
	where a.rr_id is not null and b.hours is not null and a.rloc_lat between 20.3813189 
    and 20.901608 and a.rloc_long between -103.675077 and -102.991097
    and a.rloc_lat != 0 and a.rloc_long != 0
	order by a.rr_id desc
                        ;""",

# TIME WINDOWS QUERY
            'time-distance' : """select origen.rr_id_origen, target.rr_id_target, 
			origen.length_m, origen.time_s
	from
	
	(select b.rr_id as rr_id_origen ,a.length_m ,a.time_s
	 from distances_matrix1 a
	 left join table_node_rrid b on a.orig_node = b.nearest_node
	) origen
	 
	left join 
	
	(select b.rr_id as rr_id_target ,a.length_m ,a.time_s
	 from distances_matrix1 a
	 left join table_node_rrid b on a.target_node = b.nearest_node
	) target on origen.length_m= target.length_m and origen.time_s=target.time_s """,
    
# Constraints
    
    'constraint' : """ select tas.rr_id, tas.sdate, tas.hours, tas.horario_min, tas.horario_max
from( select rr_id, a.sdate, a.hours, cast(substring(a.horario_min, 1, 2) as int) as horario_min, 
    cast(substring(a.horario_max, 1, 2) as int) as horario_max, substring(a.horario_min, 4, 5), 
    substring(a.horario_max, 4, 5)
        from
        (select distinct schedule.sdate, schedule.hours, schedule.rr_id, SPLIT_PART(schedule.hours, '-', 1) as horario_min ,SPLIT_PART(schedule.hours, '-', 2) horario_max
        from 
            (select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 1) hours
            from (select distinct sdate, hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 2) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
                
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 3) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 4) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            union
            
            select hr.sdate, hr.rr_id, SPLIT_PART(hr.hours, ',', 5) hours
            from (select  distinct sdate,hours, rr_id
                    from scheduled_datetimes
                ) as hr
            
            ) schedule
            where schedule.hours !='' and sdate in ('{d_f}') 
        ) a
        order by a.rr_id desc) tas
  
   left join
   
   (select * from recollection_request ) tes on tas.rr_id = tes.rr_id
   
  where rloc_lat !=0 """, 

  #map
  "google-map" : """ select a.rr_id, c.name, ad.address, ad.loc_lat, ad.loc_long,
		   b.sdate as schedule_date
                     from
                     
                     (select * from user_app 
                     ) c
                     
                     left join 
                     
                     (select * from address 
                     ) ad on c.id_user=ad.id_user
                     
                     left join 
                     
                     (select * from recollection_request where 
                     rr_status not in (5,4) 
                     
                     ) a on c.id_user=a.id_user
                     
                     left join 
                     
                     (select * from scheduled_datetimes
                     where sdate in ('{d_f}') 
                     ) b on a.rr_id=b.rr_id
                     
                     where a.rr_id is not null and b.hours is not null
                     order by a.rr_id DESC""",
                     
    # csv_2_driver            
    "csv_2_driver":""" select distinct a.rr_id, c.id_user, c.name, c.email, a.comments, c.cellphone , ad.address, a.other_address, ad.loc_lat, ad.loc_long,
		   b.sdate as schedule_date, b.hours
	from
	
	(select * from user_app
	) c
	
	left join 
	
	(select * from address
	) ad on c.id_user=ad.id_user
	
	left join 
	
	(select * from recollection_request where rr_status not in (5,4) --and rr_id in (1357,1358,1356,1349)
	 
	) a on c.id_user=a.id_user
	
	left join 
	
	(select * from scheduled_datetimes
	 where sdate in ('{d_f}') 
	) b on a.rr_id=b.rr_id
	
	where a.rr_id is not null and b.hours is not null
	order by a.rr_id desc"""}
