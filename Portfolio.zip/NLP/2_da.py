import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
sns.set_theme(style="whitegrid")

df = pd.read_csv('dfa.csv')
df.set_index("Date", inplace=True)

def plots():
    s_a = df['Sentiment'].value_counts()
    s_a.plot(kind = 'bar')
    plt.show()
    return
def influencers():
    df.sort_values(by=['Date'], inplace=True, ascending=True)
    print(df.head())

    # Selecciono el alcance que tuvieron los influencers.
    inf_df = df[['Influencer', 'Reach', 'TextBlob_Analysis', 'URL']]
    inf_df = inf_df.sort_values(by = 'Reach', ascending = False)
    inf_df.to_csv('top0.csv')

    top = inf_df.groupby('Influencer', as_index=False).agg({"Reach": 'sum'}).nlargest(10, columns='Reach')
    # top = inf_df.sort_values(['Influencer', 'Reach'], ascending=False).groupby('Influencer').head(10)
    top.to_csv('top.txt')
    # print(top)

    # ax = top.plot.bar(x='Influencer', y='Reach', rot=0)
    # plt.show()

def hashtags_count():

    counts = df['Hit Sentence'].str.findall(r'(#\w+)').explode().value_counts()
    counts = df['Hit Sentence'].str.findall(r'(RT\w+)').explode().value_counts()
    print(counts.head(10))

def positive_influencers():

    df_p = pd.read_csv('dfa.csv')
    inf_df = df_p[['Influencer', 'Reach', 'TextBlob_Analysis', 'Hit Sentence']]
    pos_inf = inf_df.loc[df_p['TextBlob_Analysis'].str.contains('Positive')]
    pos_inf = pos_inf.sort_values(by = 'Reach', ascending = False)
    pos_inf = pos_inf.iloc[:10]
    pos_inf.set_index('Influencer', inplace=True)
    pos_inf.plot(kind = 'bar')
    plt.show()
    pos_inf.to_csv('pos_inf.csv')

    print(pos_inf.head(10))

def negative_influencers():
    
    df_p = pd.read_csv('dfa.csv')
    inf_df = df_p[['URL','Influencer', 'Reach', 'TextBlob_Analysis', 'Hit Sentence']]
    pos_inf = inf_df.loc[df_p['TextBlob_Analysis'].str.contains('Negative')]
    pos_inf = pos_inf.sort_values(by = 'Reach', ascending = False)
    pos_inf = pos_inf.iloc[:10]
    pos_inf.set_index('Influencer', inplace=True)
    pos_inf.plot(kind = 'bar')
    plt.show()
    pos_inf.to_csv('neg_inf.csv')
    print(pos_inf.head(10))

def main():
    plots()
    influencers()
    hashtags_count()
    positive_influencers()
    negative_influencers()

if __name__ == '__main__':
    main()