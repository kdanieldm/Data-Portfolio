from textnets import Corpus, Textnet
from textnets import examples
import pandas as pd
import spacy

nlp = spacy.load("es")




top_influencers = ['@Cinepolis', '@Cinemex', '@CinetecaMexico', '@CNNEE',
                '@el_pais',  '@elespectador', '@ELTIEMPO', '@El_Universal_Mx'
                '@NoticiasCaracol', '@Milenio']

top_hashtags = ['#cine', '#alzheimer', '#tchaikovsky', '@#WonderWoman1984',
                '@BlogosDeOro',  '#Actor', '#VolvamoAlCine', '@#Efemérides']


# con esta funcion saco el grado entre usuarios y palabras
# tambien arroja los clusters

def influencer_networks():
    df = pd.read_csv('BDD_Cines_General.csv')
    df = df.loc[df['Influencer'].isin(top_influencers)]
    df = df.iloc[:10]
    print(df)
    corpus = Corpus.from_df(df, doc_col = 'Hit Sentence', lang='es')

    tn = Textnet(corpus.tokenized(), min_docs=1)
    tn.plot(label_term_nodes=True,
            label_doc_nodes=True,
            show_clusters=True)
    groups = tn.project(node_type='doc')    
    print(groups.summary())

    words = tn.project(node_type='term')
    words.plot(label_nodes=True,
           show_clusters=True)
           
    words.plot(label_nodes=True,
           scale_nodes_by='betweenness',
           color_clusters=True,
           alpha=0.5,
           node_label_filter=lambda n: n.betweenness() > words.betweenness.median())
def pos_inf():

    # red de tweets positivos

   
    df = pd.read_csv('pos_inf.csv')

    corpus = Corpus.from_df(df, doc_col = 'Hit Sentence', lang='es')

    tn = Textnet(corpus.tokenized(), min_docs=1)
    words = tn.project(node_type='term')
    words.plot(label_nodes=True,
           scale_nodes_by='betweenness',
           color_clusters=True,
           alpha=0.6,
           node_label_filter=lambda n: n.betweenness() > words.betweenness.median())
def neg_inf():
    
   # red de tweets negativos
    df = pd.read_csv('neg_inf.csv')
    corpus = Corpus.from_df(df, doc_col = 'Hit Sentence', lang='es')
    tn = Textnet(corpus.tokenized(), min_docs=1)
    tn.plot(label_term_nodes=True,
            label_doc_nodes=True,
            show_clusters=True)

    words = tn.project(node_type='term')
    words.plot(label_nodes=True,
           scale_nodes_by='betweenness',
           color_clusters=True,
           alpha=0.3,
           node_label_filter=lambda n: n.betweenness() > words.betweenness.median())




def main():
    influencer_networks()
    pos_inf()
    neg_inf()

if __name__ == '__main__':
    main()