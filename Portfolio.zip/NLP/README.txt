I worked with twitter database for merly exploratory data analysis.

1 - In the first file I cleanse the data so I can process all the information using NLP libraries in python, I removed stop words, weird characters and other stuff that may cause problems in the future.

Then I categoryze the tweets using sentiment analysis, into positive, negative and neutral and plot a word cloud to know the most common word in the db.

2 - The second file I explore the database with bar graphs to know and categorize the most valuable influencers and their tweets in relation of the reached audience.

3 - I used graph to generate communities of influencers or twitter accounts that may have some topic in common and how are those accounts correlated.







