import pandas as pd
import numpy as np
import string
import matplotlib.pyplot as plt
string.punctuation
from wordcloud import WordCloud, STOPWORDS
from collections import OrderedDict
import nltk
from textblob import TextBlob
from matplotlib.pyplot import axis, figure
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sid = SentimentIntensityAnalyzer()
nltk.download('stopwords')
import warnings
import re
warnings.filterwarnings("ignore")



def data_clean(dataframe):

    global df_a

    df = pd.read_csv(dataframe)
    print(df.head())

    # typos de datos y formas del dataframe.
    print(df.shape)
    print(df.dtypes)

    # Numerical data
    df_numeric = df.select_dtypes(include=[np.number])
    numeric_cols = df_numeric.columns.values
    print(numeric_cols)

    # Categorical or non numeric data.
    df_non_numeric = df.select_dtypes(exclude=[np.number])
    non_numeric_cols = df_non_numeric.columns.values
    print(non_numeric_cols)

    # Buscamos datos que falten, tags tiene un 100% de datos que faltan
    # Hagamos un drop.
    for i in df.columns:
        pct_missing = np.mean(df[i].isnull())
    print('{} - {}%'.format(i, round(pct_missing*100)))

    df_a = df.drop('Document Tags', axis=1)

    return df_a

def remove_punctuation(text):
    no_punct=[words for words in text if words not in string.punctuation]
    words_wo_punct=''.join(no_punct)
    return words_wo_punct

def clean_df():
    global df_a
    df_a['Hit Sentence']=df_a['Hit Sentence'].apply(lambda x: remove_punctuation(x))
    # Removemos las tildes
    cols = df_a.select_dtypes(include=[np.object]).columns
    df_a[cols] = df_a[cols].apply(lambda x: x.str.normalize('NFKD').str.encode(
                                'ascii', errors='ignore').str.decode('utf-8'))
    return df_a, cols


def token():
    global df_t
    
    def tokenize(text):
        split=re.split("\W+",text) 
        return split
    df_a['splited_list_words']=df_a['Hit Sentence'].apply(lambda x: tokenize(x.lower()))
    df_t = df_a['splited_list_words']    
    print('tokenization', df_t.head())
    return df_t

def stop_words():
    stopword = nltk.corpus.stopwords.words('spanish')
    print(stopword[:11])

    def remove_stopwords(text):
        text=[word for word in text if word not in stopword]
        return text
    df_a['text_no_stop_words'] = df_a['splited_list_words'].apply(lambda x: remove_stopwords(x))
    print('st', df_a.head())
    df_a.to_csv('corpa.csv')

def word_freq():
    global list_df

    df_a["words_f"] = df_a["text_no_stop_words"].str[0]
    list_df = df_a['words_f'].str.split(expand=True).stack().value_counts()
  
    print(list_df.head(10))
    return list_df
# Define a function to plot word cloud
def plot_cloud():
    comment_words = ''
    comment_words += " ".join(df_a['words_f'])
    stopwords = list(STOPWORDS) 
    wordcloud = WordCloud(width = 800, height = 800, 
                background_color ='white', 
                stopwords = stopwords + ["qt"], 
                min_font_size = 10).generate(comment_words) 

    # plot the WordCloud image                        
    plt.figure(figsize = (8, 8), facecolor = None) 
    plt.imshow(wordcloud) 
    plt.axis("off") 
    plt.tight_layout(pad = 0) 
    print(df_a.head())
    plt.show() 


### Sentiment Analysis ### --------------------
def sentiment_analysis():
    def getSubjectivity(text):
        return TextBlob(text).sentiment.subjectivity

    def getPolarity(text):
        return TextBlob(text).sentiment.polarity
    
    #CREA DOS COLUMNAS CON SUBJETIVIDAD Y POLARIDAD.
    df_a['TextBlob_Subjectivity'] = df_a['Hit Sentence'].apply(getSubjectivity)
    df_a['TextBlob_Polarity'] = df_a['Hit Sentence'].apply(getPolarity)

    def getAnalysis(score):
        if score < 0:
            return 'Negative'
        elif score == 0:
            return 'Neutral'
        else:
            return 'Positive'
    df_a['TextBlob_Analysis'] = df_a['TextBlob_Polarity'].apply(getAnalysis )
    print(df_a['TextBlob_Analysis'])

    # df_a.to_csv('dfa.csv') #ES EL ARCHIVO OUTPUT CON LA CLASIFICACION
    
    hist = df_a['TextBlob_Analysis'].hist()
    hist.plot()
    plt.show()
    return df_a
    
def main():

    data_clean('BDD_Cines_General.csv') #Esta funcion hace una limpiexa de datos
    
    token() # Tokeniza las palabras
    stop_words() # Remueve stopwords
    word_freq()  # calcula la frecuencia de palabras
    plot_cloud() # crea el wordcloud
    sentiment_analysis() # analisis de sentimientos, lo agrega a un dataframe




if __name__ == '__main__':
    main()